from flask import Flask, render_template, request
import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier
iris = load_iris()
X = iris.data
y = iris.target
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    sepal_length = float(request.form['sepal_length'])
    sepal_width = float(request.form['sepal_width'])
    petal_length = float(request.form['petal_length'])
    petal_width = float(request.form['petal_width'])
    
    # Create a new sample with the user inputs
    sample = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
    
    # Train a K-Nearest Neighbors model
    knn = KNeighborsClassifier()
    knn.fit(X, y)
    
    # Make a prediction using the user inputs
    prediction = knn.predict(sample)
    
    # Get the corresponding species name
    species = iris.target_names[prediction[0]]
    
    return render_template('index.html', prediction=species)
if __name__ == '__main__':
    app.run(debug=True)
